import streamlit as st
import openai
import os

# Configuration de l'API OpenAI
openai.api_key = st.secrets["OPENAI_API_KEY"]

# Interface Streamlit
st.title("🧠 NeoChat AI")
st.subheader("Discutez. Connectez. Réfléchissez.")

st.image("https://milyes.github.io/netsecurepro-files/neochat_logo.png", width=300)

question = st.text_input("Posez une question à NeoChat AI :")

if question:
    with st.spinner("Réflexion en cours..."):
        try:
            reponse = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Tu es NeoChat AI, un assistant intelligent et amical."},
                    {"role": "user", "content": question}
                ]
            )
            texte_reponse = reponse["choices"][0]["message"]["content"]
            st.success(texte_reponse)
        except Exception as e:
            st.error(f"Erreur : {str(e)}")