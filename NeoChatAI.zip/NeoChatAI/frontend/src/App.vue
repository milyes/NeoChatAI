<template>
  <div class="p-4 text-white bg-gray-900 h-screen flex flex-col">
    <h1 class="text-2xl font-bold mb-4">NeoChat AI</h1>
    <div class="flex-1 overflow-y-auto border border-gray-700 p-2 rounded" ref="chatbox">
      <div v-for="msg in messages" :key="msg" class="mb-1">{{ msg }}</div>
    </div>
    <input v-model="message" @keyup.enter="send" class="mt-4 p-2 text-black rounded" placeholder="Écris un message...">
  </div>
</template>

<script>
export default {
  data() {
    return {
      message: '',
      messages: [],
      socket: null
    };
  },
  mounted() {
    this.socket = new WebSocket("ws://localhost:8000/ws/chat");
    this.socket.onmessage = (event) => {
      this.messages.push(event.data);
    };
  },
  methods: {
    send() {
      if (this.message) {
        this.socket.send(this.message);
        this.messages.push(this.message);
        this.message = '';
      }
    }
  }
}
</script>