#!/data/data/com.termux/files/usr/bin/bash

echo "🚀 Lancement complet de NeoChatAI avec logs + arrêt automatique"

# Ports
BACKEND_PORT=8000
FRONTEND_PORT=5173

# Créer log directory si besoin
mkdir -p logs

# Lancer le backend
echo "🔧 Lancement backend FastAPI..."
cd backend
pip install fastapi uvicorn --quiet
uvicorn app.main:app --host 0.0.0.0 --port $BACKEND_PORT > ../logs/backend.log 2>&1 &
BACKEND_PID=$!
cd ..

# Lancer le frontend
echo "💻 Lancement frontend Vue.js..."
cd frontend
npm install --silent
npm run dev > ../logs/frontend.log 2>&1 &
FRONTEND_PID=$!
cd ..

# Lancer le tunnel Cloudflare
echo "🌐 Tunnel sécurisé Cloudflare vers backend (port $BACKEND_PORT)..."
cloudflared tunnel --url http://localhost:$BACKEND_PORT &
TUNNEL_PID=$!

# Fonction d'arrêt propre
cleanup() {
  echo "🛑 Arrêt de tous les services..."
  kill $BACKEND_PID
  kill $FRONTEND_PID
  kill $TUNNEL_PID
  echo "✅ Services arrêtés proprement."
  exit 0
}

# Catch Ctrl+C
trap cleanup SIGINT

echo "✅ NeoChatAI est en cours d'exécution. Logs dans ./logs/"
wait

